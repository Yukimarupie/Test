class Answer < ApplicationRecord
  belongs_to :question

end

