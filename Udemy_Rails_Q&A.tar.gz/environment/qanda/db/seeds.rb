Question.create(id: 1, name: 'Test name1', title: 'Test question1', content:'Test content1')
Question.create(id: 2, name: 'Test name2', title: 'Test question2', content:'Test content2')
Question.create(id: 3, name: 'Test name3', title: 'Test question3', content:'Test content3')